# JOY365-App

אפליקציה להצגת מוצרי קוסמטיקה מתוך חנות JOY365 עם ממשק רכישה מהיר.

## 🧩 מבנה הפרויקט

```
JOY365-App/
├── backend/
│   ├── app.py
│   ├── products_data.json
│   └── requirements.txt
│
├── frontend/
│   ├── App.js
│   ├── package.json
│   └── README.md
```

## 🚀 התקנה והרצה

### Backend – Flask API
```bash
cd backend
python -m venv venv
source venv/bin/activate  # ב-Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

### Frontend – React Native (Expo)
```bash
cd frontend
npm install
npm start
```

## 🔗 API Endpoints
- /categories
- /subcategories?category=...
- /products?sub_category=...
- /buy/<product_id>
